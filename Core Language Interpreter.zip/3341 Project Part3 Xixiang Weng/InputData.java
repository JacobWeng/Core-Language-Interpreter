package edu.c3341;

import java.util.ArrayList;
import java.util.Scanner;

public class InputData {
    private ArrayList<Integer> list;
    private int index;
    private static InputData input;
    private InputData(){
        list = new ArrayList<>();
        index = 0;
    }
    public static InputData getInput(){
        if(input == null){
            input=new InputData();
        }
        return input;
    }
    
    public void scan(Scanner in){
        while(in.hasNextInt()){
            list.add(in.nextInt());
        }
    }
    
    // scan next integer data
    public int nextVal(){
        if(index < list.size()){
            int temp = index;
            index += 1;
            return list.get(temp);
        }
        return 0;
    }
}
