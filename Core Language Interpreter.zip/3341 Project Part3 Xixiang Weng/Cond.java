package edu.c3341;

public class Cond {
	private Comp comp;
	private Cond cond1;
	private Cond cond2;
	private boolean isNegation;
	private boolean isAnd;
	private boolean isOr;

	// evaluate the cond in different cases
	public boolean evalCond() {
		boolean res;
		if (isAnd) {
			res = cond1.evalCond() && cond2.evalCond();
		} else if (isOr) {
			res = cond1.evalCond() || cond2.evalCond();
		} else if (isNegation) {
			res = !cond1.evalCond();
		} else {
			res = comp.evalComp();
		}
		return res;
	}
	
	// parser of Cond
	public void parseCond() {
		Tokenizer tokenizer = Tokenizer.create();
		TokenKind kind = tokenizer.getToken();

		/*
		 * check which kind of condition it is
		 */
		if (kind == TokenKind.EXCALMATORY_MARK) {

			// consume "!"
			tokenizer.skipToken();
			isNegation = true;
			cond1 = new Cond();
			cond1.parseCond();
		} else if (kind == TokenKind.LEFT_BRACKET) {

			// consume "["
			tokenizer.skipToken();
			cond1 = new Cond();
			cond1.parseCond();
			kind = tokenizer.getToken();
			if (kind == TokenKind.AND_OPERATOR) {

				// consume "&&"
				tokenizer.skipToken();
				isAnd = true;
				cond2 = new Cond();
				cond2.parseCond();
			} else if (kind == TokenKind.OR_OPERATOR) {

				// consume "or"
				tokenizer.skipToken();
				isOr = true;
				cond2 = new Cond();
				cond2.parseCond();
			} else if (kind == TokenKind.RIGHT_BRACKET) {
			} else {
				System.err.println("Error: invalid syntax in Cond");
				System.exit(1);
			}

			// consume "]"
			tokenizer.skipToken();
		} else {
			
			// parse comp if all condition above don't fit
			comp = new Comp();
			comp.parseComp();
		}
	}

	// printer of Cond
	public void printCond() {
		if (comp != null) {
			comp.printComp();
		} else if (isNegation) {
			System.out.print("!");
			cond1.printCond();
		} else if (isAnd) {
			System.out.print("[");
			cond1.printCond();
			System.out.print(" && ");
			cond2.printCond();
			System.out.print("]");
		} else if (isOr) {
			System.out.print("[");
			cond1.printCond();
			System.out.print(" || ");
			cond2.printCond();
			System.out.print("]");
		}
	}
	
	// executor of Cond
	public void execCond() {
		// no code needed here
	}
}
