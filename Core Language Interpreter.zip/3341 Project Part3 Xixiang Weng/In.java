package edu.c3341;

public class In {
	private IdList idList;

	public void parseIn() {
		Tokenizer tokenizer = Tokenizer.create();
		TokenKind kind = tokenizer.getToken();

		// check the keyword "read"
		if (kind != TokenKind.READ) {
			System.err.println("Error: missing keyword-read");
			System.exit(1);
		}

		// consume "read"
		tokenizer.skipToken();
		idList = new IdList();
		idList.parseIdList();
		kind = tokenizer.getToken();

		// check semicolon
		if (kind != TokenKind.SEMICOLON) {
			System.err.println("Error: missing semicolon");
			System.exit(1);
		}

		// consume semicolon
		tokenizer.skipToken();
	}

	// printer of In
	public void printIn() {
		PrettyPrint.print("read ");
		idList.printIdList();
		System.out.println(";");
	}

	// executor of In
	public void execIn() {
		IdList originalList = idList;
		while (idList != null && idList.getId() != null) {
			idList.getId().setValue(InputData.getInput().nextVal());
			idList = idList.nextList();
		}
		idList = originalList;
	}
}
