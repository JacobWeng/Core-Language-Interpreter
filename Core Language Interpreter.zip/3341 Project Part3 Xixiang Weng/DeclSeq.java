package edu.c3341;

public class DeclSeq {
	private Decl d;
	private DeclSeq ds;

	// parser of DeclSeq
	public void parseDeclSeq() {
		Tokenizer tokenizer = Tokenizer.create();
		TokenKind kind = tokenizer.getToken();

		// catch keyword-int to catch Decl object
		if (kind == TokenKind.INT) {
			d = new Decl();
			d.parseDecl();
			ds = new DeclSeq();
			ds.parseDeclSeq();
		}
	}

	// printer of DeclSeq
	public void printDeclSeq() {
		if (d != null) {
			d.printDecl();
		}
		if (ds != null) {
			ds.printDeclSeq();
		}
	}

	// executor of DeclSeq
	public void execDeclSeq() {
		// no code needed here
	}
}
