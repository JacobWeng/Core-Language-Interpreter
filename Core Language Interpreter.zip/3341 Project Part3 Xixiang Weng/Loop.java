package edu.c3341;

public class Loop {
    private Cond cond;
    private StmtSeq ss;
    
    // parser of Loop
    public void parseLoop(){
        Tokenizer tokenizer = Tokenizer.create();
        TokenKind kind = tokenizer.getToken();
        
        // check keyword "while"
        if(kind != TokenKind.WHILE){
            System.err.println("Error: error syntax in Loop");
            System.exit(1);
        }
        
        // consume "while"
        tokenizer.skipToken();
        cond = new Cond();
        cond.parseCond();
        kind = tokenizer.getToken();
        
        // check keyword "loop"
        if(kind!=TokenKind.LOOP){
            System.err.println("Error: missing keyword-loop");
            System.exit(1);
        }
        
        // consume "loop"
        tokenizer.skipToken();
        ss = new StmtSeq();
        ss.parseStmtSeq();
        kind = tokenizer.getToken();
        
        // check keyword "end"
        if(kind!=TokenKind.END){
            System.err.println("Error: missing keyword-end");
            System.exit(1);
        }
        
        //consume "end"
        tokenizer.skipToken();
        kind = tokenizer.getToken();
        
        //check semicolon
        if(kind!=TokenKind.SEMICOLON){
            System.err.println("Error: missing semicolon");
            System.exit(1);
        }
        
        //consume semicolon
        tokenizer.skipToken();
    }
    
    // printer of Loop
    public void printLoop(){
        PrettyPrint.print("while ");
        cond.printCond();
        System.out.println(" loop");
        PrettyPrint.moreIndent();
        ss.printStmtSeq();
        PrettyPrint.lessIndent();
        PrettyPrint.println("end;");
    }
    
    // executor of Loop
    public void execLoop(){
        while(cond.evalCond()){
            ss.execStmtSeq();
        }
    }
}
