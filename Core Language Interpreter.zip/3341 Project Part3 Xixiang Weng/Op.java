package edu.c3341;

public class Op {
    private Exp exp;
    private boolean isExp;
    private int val;
    private Id id;
    private boolean isId;
    
    // evaluate the Op in different cases
    public int evalOp(){
    	int res = val;
        if(isExp) {
        	res = exp.evalExp();
        }
        else if(isId) {
        	res = id.getVal();
        }
        return res;
    }
    
    // parser of Op
    public void parseOp(){
        Tokenizer tokenizer = Tokenizer.create();
        TokenKind kind = tokenizer.getToken();
        if(kind == TokenKind.LEFT_PARENTHESIS){
            isExp = true;
            exp = new Exp();
            exp.parseExp();
            
            //consume "("
            tokenizer.skipToken();
        }else if(kind == TokenKind.INTEGER_CONSTANT){
            val=tokenizer.intVal();
        }else if(kind == TokenKind.IDENTIFIER){
            isId = true;
            id = Id.getId(tokenizer.idName());
        }else{
            System.err.println("Error: error syntax in Op");
            System.exit(1);
        }

    }
    
    // printer of Op
    public void printOp(){
        if(isExp){
            System.out.print("(");
            exp.printExp();
            System.out.print(")");
        }else if(isId){
            id.printId();
        }else{
            System.out.print(val);
        }
    }
    
    // executor of Op
    public void execOp() {
    	// no code needed here
    }
}
