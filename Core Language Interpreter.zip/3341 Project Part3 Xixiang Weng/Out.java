package edu.c3341;

public class Out {
    private IdList idList;
    
    // parser of Out
    public void parseOut(){
        Tokenizer tokenizer = Tokenizer.create();
        TokenKind kind = tokenizer.getToken();
        
        // check keyword "write" 
        if(kind != TokenKind.WRITE){
            System.err.println("Error: missing keyword-write");
            System.exit(1);
        }
        
        //consume "write"
        tokenizer.skipToken();
        idList = new IdList();
        idList.parseIdList();
        kind=tokenizer.getToken();
        
        // check semicolon 
        if(kind!=TokenKind.SEMICOLON){
            System.err.println("Error: missing semicolon");
            System.exit(1);
        }
        
        // consume semicolon
        tokenizer.skipToken();
    }
    
    // printer of Out
    public void printOut(){
        PrettyPrint.print("write ");
        idList.printIdList();
        System.out.println(";");
    }
    
    // executor of Out
    public void execOut(){
        IdList originalList = idList;
        
        // check out whether the id list is valid to be write out
        if(idList != null && idList.getId() != null && idList.getIdName() != null) {
            System.out.println(idList.getIdName()+" = "+ idList.getIdVal());
            idList = idList.nextList();
            execOut();
        }
        idList = originalList;
    }
}

