package edu.c3341;

public class If {
	private Cond cond;
	private StmtSeq ss1;
	private StmtSeq ss2;

	// parser of If
	public void parseIf() {
		Tokenizer tokenizer = Tokenizer.create();
		TokenKind kind = tokenizer.getToken();

		// check the syntax
		if (kind != TokenKind.IF) {
			System.err.println("Error: error in If syntax");
			System.exit(1);
		}

		// consume "If"
		tokenizer.skipToken();
		cond = new Cond();
		cond.parseCond();
		kind = tokenizer.getToken();

		// check keyword-then
		if (kind != TokenKind.THEN) {
			System.err.println("Error: missing keyword-then");
			System.exit(1);
		}

		// consume "then"
		tokenizer.skipToken();
		ss1 = new StmtSeq();
		ss1.parseStmtSeq();
		kind = tokenizer.getToken();
		if (kind == TokenKind.ELSE) {
			// skip "else"
			tokenizer.skipToken();
			ss2 = new StmtSeq();
			ss2.parseStmtSeq();
		}
		kind = tokenizer.getToken();

		// check keyword-end
		if (kind != TokenKind.END) {
			System.err.println("Error: missing keyword-end");
			System.exit(1);
		}

		// consume "end"
		tokenizer.skipToken();
		kind = tokenizer.getToken();

		// check semicolon
		if (kind != TokenKind.SEMICOLON) {
			System.err.println("Error: missing semicolon");
			System.exit(1);
		}

		// consume semicolon
		tokenizer.skipToken();
	}

	// printer of If
	public void printIf() {
		PrettyPrint.print("if ");
		cond.printCond();
		System.out.print(" then");
		System.out.println();
		PrettyPrint.moreIndent();
		ss1.printStmtSeq();
		PrettyPrint.lessIndent();
		if (ss2 != null) {
			PrettyPrint.println("else");
			PrettyPrint.moreIndent();
			ss2.printStmtSeq();
			PrettyPrint.lessIndent();
		}
		PrettyPrint.println("end;");
	}

	// executor of If
	public void execIf() {
		if (cond.evalCond()) {
			ss1.execStmtSeq();
			return;
		}
		if (ss2 != null)
			ss2.execStmtSeq();
	}
}
