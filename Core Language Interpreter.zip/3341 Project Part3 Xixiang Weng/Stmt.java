package edu.c3341;

public class Stmt {
	private int altNo;
	private Assign s1;
	private If s2;
	private Loop s3;
	private In s4;
	private Out s5;

	// parser of Stmt
	public void parseStmt() {
		Tokenizer tokenizer = Tokenizer.create();
		TokenKind kind = tokenizer.getToken();

		// check if which kind of Stmt
		if (kind == TokenKind.IDENTIFIER) {

			// parse Assign
			altNo = 1;
			s1 = new Assign();
			s1.parseAssign();
		} else if (kind == TokenKind.IF) {

			// parse IF
			altNo = 2;
			s2 = new If();
			s2.parseIf();
		} else if (kind == TokenKind.WHILE) {

			// parse LOOP
			altNo = 3;
			s3 = new Loop();
			s3.parseLoop();
		} else if (kind == TokenKind.READ) {

			// parse IN
			altNo = 4;
			s4 = new In();
			s4.parseIn();
		} else if (kind == TokenKind.WRITE) {

			// parse OUT
			altNo = 5;
			s5 = new Out();
			s5.parseOut();
		} else {
			System.err.println("Error: error syntax in Stmt");
		}
	}

	// printer of Stmt
	public void printStmt() {
		if (altNo == 1) {
			s1.printAssign();
		} else if (altNo == 2) {
			s2.printIf();
		} else if (altNo == 3) {
			s3.printLoop();
		} else if (altNo == 4) {
			s4.printIn();
		} else if (altNo == 5) {
			s5.printOut();
		}
	}

	// executor of Stmt
	public void execStmt() {
		if (altNo == 1) {
			s1.execAssign();
		} else if (altNo == 2) {
			s2.execIf();
		} else if (altNo == 3) {
			s3.execLoop();
		} else if (altNo == 4) {
			s4.execIn();
		} else if (altNo == 5) {
			s5.execOut();
		}
	}
}
