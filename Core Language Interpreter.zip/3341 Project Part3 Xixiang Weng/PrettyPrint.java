package edu.c3341;

public class PrettyPrint {
    private static int numOfIndent = 0;
    public PrettyPrint(){
    }
    public static void moreIndent(){
    	numOfIndent++;
    }
    public static void lessIndent(){
    	numOfIndent--;
    }
    public static void Indent(){
        for(int i = 0; i < numOfIndent;i++){
            System.out.print("    ");
        }
    }
    public static void print(String s){
        Indent();
        System.out.print(s);
    }
    public static void println(String s){
        Indent();
        System.out.println(s);
    }
}
