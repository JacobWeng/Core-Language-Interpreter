package edu.c3341;

import java.util.Arrays;
import java.util.Scanner;

public class Tokenizer {

	// set up class variable
	private int frontDigit;
	private String frontId;
	private String remainder;
	private TokenKind kind;
	private static String SPECIAL_SYMBOL_AND_WHITESPACE[] = { " ", "\n", "\t", "\r", ";", ",", "=", "!", "[", "]", "&&",
			"||", "(", ")", "+", "-", "*", "!=", "==", "<", ">", "<=", ">=" };
	
	//using private to make singleton
	private static Tokenizer tokenizer;
	private Tokenizer() {
		this.remainder = null;
	}
	
	public static Tokenizer create() {
		if (tokenizer == null) {
			tokenizer = new Tokenizer();
		}
		return tokenizer;
	}

	//scan the inputfile into tokenizer
	public void scan(Scanner in) {
		this.remainder = "";
		while (in.hasNext()) {
			String line = in.nextLine() + "\n";
			this.remainder += line;
		}
		Tokenizer.tokenizer.skipToken();
	}
 
   /**
    * Return the kind of the front token. (Restores this.)
    *
    * @return the kind of the front token
    * @ensures getToken = [the kind of token this.front]
    */
	public TokenKind getToken() {
		return this.kind;
	}

   /**
    * Skip front token.
    *
    * @updates this
    * @ensures <pre>(if [the token kind of #this.front is good and legal]
    *                  then this.front * this.remainder = #this.remainder)  or
    *          ([the token kind of #this.front is EOF] and
    *          this = #this)</pre>
    */
	public void skipToken() {

		// check out if the remainder is empty
		if (this.remainder.length() > 0) {
			char first = this.remainder.charAt(0);

			// case for handling whitespace
			if (first == ' ' || first == '\n' || first == '\t' || first == '\r') {
				this.remainder = this.remainder.substring(1);

				// recursively scan next character
				skipToken();
			}

			// case for handling reversed word and identifier
			else if (Character.isAlphabetic(first)) {
				handleCharSeq();
			}

			// case for handling digit
			else if (Character.isDigit(first)) {
				handleDigit();
			}

			// case for handling special symbol
			else {
				handleSpecialSymbol();
			}
		} else {
			this.kind = TokenKind.EOF;
		}
	}

	// handling the digit condition
	public void handleDigit() {
		int i = 1;
		while (Character.isDigit(this.remainder.charAt(i))) {
			i++;
		}
		char end = this.remainder.charAt(i);
		if (Character.isLowerCase(end) || Character.isUpperCase(end)) {
			this.kind = TokenKind.ERROR;
		}
		this.frontDigit = Integer.parseInt(this.remainder.substring(0,i));
		this.remainder = this.remainder.substring(i);
		this.kind = TokenKind.INTEGER_CONSTANT;
	}

	// handling the special symbol condition. "!=", "==", "<=" and ">=" need to be
	// evaluated before "!", "=", ">" and "<" to avoid bug.
	public void handleSpecialSymbol() {
		if (this.remainder.indexOf(";") == 0) {
			this.kind = TokenKind.SEMICOLON;
			this.remainder = this.remainder.substring(1);
		} else if (this.remainder.indexOf(",") == 0) {
			this.kind = TokenKind.COMMA;
			this.remainder = this.remainder.substring(1);
		} else if (this.remainder.indexOf("==") == 0) {
			this.kind = TokenKind.EQUALITY_TEST;
			this.remainder = this.remainder.substring(2);
		} else if (this.remainder.indexOf("=") == 0) {
			this.kind = TokenKind.ASSIGNMENT_OPERATOR;
			this.remainder = this.remainder.substring(1);
		} else if (this.remainder.indexOf("!=") == 0) {
			this.kind = TokenKind.NOT_EQUAL_TEST;
			this.remainder = this.remainder.substring(2);
		} else if (this.remainder.indexOf("!") == 0) {
			this.kind = TokenKind.EXCALMATORY_MARK;
			this.remainder = this.remainder.substring(1);
		} else if (this.remainder.indexOf("[") == 0) {
			this.kind = TokenKind.LEFT_BRACKET;
			this.remainder = this.remainder.substring(1);
		} else if (this.remainder.indexOf("]") == 0) {
			this.kind = TokenKind.RIGHT_BRACKET;
			this.remainder = this.remainder.substring(1);
		} else if (this.remainder.indexOf("&&") == 0) {
			this.kind = TokenKind.AND_OPERATOR;
			this.remainder = this.remainder.substring(2);
		} else if (this.remainder.indexOf("||") == 0) {
			this.kind = TokenKind.OR_OPERATOR;
			this.remainder = this.remainder.substring(2);
		} else if (this.remainder.indexOf("(") == 0) {
			this.kind = TokenKind.LEFT_PARENTHESIS;
			this.remainder = this.remainder.substring(1);
		} else if (this.remainder.indexOf(")") == 0) {
			this.kind = TokenKind.RIGHT_PARENTHESIS;
			this.remainder = this.remainder.substring(1);
		} else if (this.remainder.indexOf("+") == 0) {
			this.kind = TokenKind.PLUS_OPERATOR;
			this.remainder = this.remainder.substring(1);
		} else if (this.remainder.indexOf("-") == 0) {
			this.kind = TokenKind.MINUS_OPERATOR;
			this.remainder = this.remainder.substring(1);
		} else if (this.remainder.indexOf("*") == 0) {
			this.kind = TokenKind.MULTIPLICATION_OPERATOR;
			this.remainder = this.remainder.substring(1);
		} else if (this.remainder.indexOf("<=") == 0) {
			this.kind = TokenKind.SMALLER_OR_EQUAL_TEST;
			this.remainder = this.remainder.substring(2);
		} else if (this.remainder.indexOf(">=") == 0) {
			this.kind = TokenKind.LARGER_OR_EQUAL_TEST;
			this.remainder = this.remainder.substring(2);
		} else if (this.remainder.indexOf("<") == 0) {
			this.kind = TokenKind.SMALLER_TEST;
			this.remainder = this.remainder.substring(1);
		} else if (this.remainder.indexOf(">") == 0) {
			this.kind = TokenKind.LARGER_TEST;
			this.remainder = this.remainder.substring(1);
		} else {
			this.kind = TokenKind.ERROR;
		}
	}

	// check if the sequence of character is truly a reserved word or an identifier
	// has the same prefix as a reserved word
	public boolean isReservedWord(int lengthOfReservedWord) {
		boolean result = true;
		String remainder = this.remainder.substring(lengthOfReservedWord);
		if (!Arrays.asList(SPECIAL_SYMBOL_AND_WHITESPACE).contains(String.valueOf(remainder.charAt(0)))) {
			result = false;
		}
		return result;
	}

	// handling the token whose prefix is beginning with an alphabetic letter
	public void handleCharSeq() {

		// handle the reserved word
		if (this.remainder.indexOf("program") == 0 && isReservedWord(7)) {
			this.kind = TokenKind.PROGRAM;
			this.remainder = this.remainder.substring(7);
		} else if (this.remainder.indexOf("begin") == 0 && isReservedWord(5)) {
			this.kind = TokenKind.BEGIN;
			this.remainder = this.remainder.substring(5);
		} else if (this.remainder.indexOf("end") == 0 && isReservedWord(3)) {
			this.kind = TokenKind.END;
			this.remainder = this.remainder.substring(3);
		} else if (this.remainder.indexOf("int") == 0 && isReservedWord(3)) {
			this.kind = TokenKind.INT;
			this.remainder = this.remainder.substring(3);
		} else if (this.remainder.indexOf("if") == 0 && isReservedWord(2)) {
			this.kind = TokenKind.IF;
			this.remainder = this.remainder.substring(2);
		} else if (this.remainder.indexOf("then") == 0 && isReservedWord(4)) {
			this.kind = TokenKind.THEN;
			this.remainder = this.remainder.substring(4);
		} else if (this.remainder.indexOf("else") == 0 && isReservedWord(4)) {
			this.kind = TokenKind.ELSE;
			this.remainder = this.remainder.substring(4);
		} else if (this.remainder.indexOf("while") == 0 && isReservedWord(5)) {
			this.kind = TokenKind.WHILE;
			this.remainder = this.remainder.substring(5);
		} else if (this.remainder.indexOf("loop") == 0 && isReservedWord(4)) {
			this.kind = TokenKind.LOOP;
			this.remainder = this.remainder.substring(4);
		} else if (this.remainder.indexOf("read") == 0 && isReservedWord(4)) {
			this.kind = TokenKind.READ;
			this.remainder = this.remainder.substring(4);
		} else if (this.remainder.indexOf("write") == 0 && isReservedWord(5)) {
			this.kind = TokenKind.WRITE;
			this.remainder = this.remainder.substring(5);
		}

		// case for handling identifier
		else {
			handleIdentifier();
		}
	}

	// handling the identifier condition
	public void handleIdentifier() {
		char first = this.remainder.charAt(0);
		int i = 0;

		if (Character.isUpperCase(first)) {
			i++;
			while (Character.isUpperCase(this.remainder.charAt(i))) {
				i++;
			}
			while (Character.isDigit(this.remainder.charAt(i))) {
				i++;
			}
			char end = this.remainder.charAt(i);
			if (Character.isLowerCase(end) || Character.isUpperCase(end)) {
				this.kind = TokenKind.ERROR;
			}
			this.frontId=this.remainder.substring(0,i);
			this.remainder = this.remainder.substring(i);
			this.kind = TokenKind.IDENTIFIER;
		} else {
			this.kind = TokenKind.ERROR;
		}
	}
	
   /**
    * Return the integer value of the front INTEGER_CONSTANT token. (Restores
    * this.)
    *
    * @return the integer value of the front INTEGER_CONSTANT token
    * @requires [the kind of this.front is INTEGER_CONSTANT]
    * @ensures intVal = [the integer value of this.front]
    */
	public int intVal() {
		int res = this.frontDigit;
		this.frontDigit = 0;
		return res;
	}

   /**
    * Return the name of the front IDENTIFIER token. (Restores this.)
    *
    * @return the name of the front IDENTIFIER token
    * @requires [the kind of this.front is IDENTIFIER]
    * @ensures intVal = this.front
    */
	public String idName() {
		String res = this.frontId;
		this.frontId = null;
		return res;
	}
}