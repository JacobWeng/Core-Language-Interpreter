package edu.c3341;

public class Exp {
    private Trm trm;
    private Exp exp;
    private boolean isPlus;
    private boolean isMinus;
    
    // evaluate the Exp in different cases
    public int evalExp(){
    	int res = trm.evalTrm();
        if(isPlus) {
        	res += exp.evalExp();
        }
        else if(isMinus) {
        	res -= exp.evalExp();
        }
        return res;
    }
    
    // parser of Exp
    public void parseExp(){
        Tokenizer tokenizer = Tokenizer.create();
        trm = new Trm();
        trm.parseTrm();
        TokenKind kind = tokenizer.getToken();
        if(kind == TokenKind.PLUS_OPERATOR){
        	
            // consume "+"
            tokenizer.skipToken();
            isPlus = true;
            exp = new Exp();
            exp.parseExp();
        }else if(kind == TokenKind.MINUS_OPERATOR){
        	
            // consume "-"
            tokenizer.skipToken();
            isMinus = true;
            exp = new Exp();
            exp.parseExp();
        }
    }
    
    // printer of Exp
    public void printExp(){
        trm.printTrm();
        if(isPlus){
            System.out.print(" + ");
            exp.printExp();
        }else if(isMinus){
            System.out.print(" - ");
            exp.printExp();
        }
    }
    
    // executor of Exp
    public void execExp() {
    	//no code needed here
    }
}
