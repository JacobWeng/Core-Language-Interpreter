package edu.c3341;

public class Assign {
    private Id id;
    private Exp exp;
    
    // parser of Assign
    public void parseAssign(){
        Tokenizer tokenizer = Tokenizer.create();
        TokenKind kind = tokenizer.getToken();
        String idName = tokenizer.idName();
        
        // check if the Identifier is valid
        if(kind != TokenKind.IDENTIFIER || idName == null){
            System.err.println("Error: wrong syntax in identifier");
            System.exit(1);
        }  
        id = Id.getId(idName);

        // consume Identifier and the "="
        tokenizer.skipToken();
        tokenizer.skipToken();
        
        // parse the Exp
        exp = new Exp();
        exp.parseExp();
        kind = tokenizer.getToken();
        if(kind != TokenKind.SEMICOLON){
            System.err.println("Error: missing semicolon");
            System.exit(1);
        }
        
        // consume semicolon
        tokenizer.skipToken();
    }
    
    // printer of the Assign
    public void printAssign(){
        PrettyPrint.Indent();
        id.printId();
        System.out.print(" = ");
        exp.printExp();
        System.out.println(";");
    }
    
    // executor of Assign
    public void execAssign(){
        if(id != null) {
        	id.setValue(exp.evalExp());
        }
    }
}
