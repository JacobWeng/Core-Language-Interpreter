package edu.c3341;

public class Prog {
	private DeclSeq ds;
	private StmtSeq ss;

	// parser of Prog
	public void parseProg() {
		Tokenizer tokenizer = Tokenizer.create();
		TokenKind kind = tokenizer.getToken();
		if (kind != TokenKind.PROGRAM) {
			System.err.println("Error: program should start with keyword-program");
			System.exit(1);
		}

		// consume "program"
		tokenizer.skipToken();
		ds = new DeclSeq();
		ds.parseDeclSeq();
		kind = tokenizer.getToken();
		if (kind != TokenKind.BEGIN) {
			System.err.println("Error: program miss keyword-begin");
			System.exit(1);
		}

		// consume "begin"
		tokenizer.skipToken();
		ss = new StmtSeq();
		ss.parseStmtSeq();

		// check if the Prog end with "end"
		kind = tokenizer.getToken();
		if (kind != TokenKind.END) {
			System.err.println("Error: program miss keyword-end");
			System.exit(1);
		}

		// consume "end"
		tokenizer.skipToken();
	}

	// printer of Prog
	public void printProg() {
		System.out.println("program");
		PrettyPrint.moreIndent();
		ds.printDeclSeq();
		System.out.println("begin");
		ss.printStmtSeq();
		PrettyPrint.lessIndent();
		System.out.println("end");
	}

	// executor of Prog
	public void execProg() {
		ds.execDeclSeq();
		ss.execStmtSeq();
	}
}
