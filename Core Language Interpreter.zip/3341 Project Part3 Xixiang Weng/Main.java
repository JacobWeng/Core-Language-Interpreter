package edu.c3341;

import java.util.Scanner;
import java.nio.file.Paths;
import java.io.IOException;

public class Main {
    public static void main(String[] args) {
        Tokenizer tokenizer=Tokenizer.create();
        InputData input=InputData.getInput();
        
        // input the program file
        Scanner file;
        try {
            file = new Scanner(Paths.get(args[0]));
        }catch (IOException e) {
            System.err.println("Error opening file: " + args[0]);
            return;
        }
        tokenizer.scan(file);
        
        // input the data associated with program
        Scanner data;
        try{
            data=new Scanner(Paths.get(args[1]));
        }catch (IOException e) {
            System.err.println("Error opening file: " + args[1]);
            return;
        }
        input.scan(data);
        
        // parse the program
        Prog program=new Prog();
        program.parseProg();
        
        // print the program
        if(args[2].equals("print")) {
        	program.printProg();
        	
        	// executor the program
            program.execProg();
        } else if(args[2].equals("doNotPrint")) {
        	
        	// executor the program
            program.execProg();
        }
        else if(!args[2].equals("doNotPrint")){
            System.err.println("Error: invalid command, you should type print or doNorPrint here");
            System.exit(1);
        }
    }
}
