package edu.c3341;

public class StmtSeq {
	private Stmt s;
	private StmtSeq ss;

	// parser of StmtSeq
	public void parseStmtSeq() {
		Tokenizer tokenizer = Tokenizer.create();
		TokenKind kind = tokenizer.getToken();

		// check if there exists StmtSeq
		if (kind == TokenKind.IDENTIFIER || kind == TokenKind.IF || kind == TokenKind.WHILE || kind == TokenKind.READ
				|| kind == TokenKind.WRITE) {
			s = new Stmt();
			s.parseStmt();
			ss = new StmtSeq();
			ss.parseStmtSeq();
		}
	}

	// printer of StmtSeq
	public void printStmtSeq() {
		if (s != null) {
			s.printStmt();
		}
		if (ss != null) {
			ss.printStmtSeq();
		}
	}

	// executor of StmtSeq
	public void execStmtSeq() {
		if (s != null) {
			s.execStmt();
		}
		if (ss != null) {
			ss.execStmtSeq();
		}
	}
}
