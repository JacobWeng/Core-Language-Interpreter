package edu.c3341;

public class IdList {
	private Id id;
	private IdList idList;

	public Id getId() {
		return id;
	}

	// get the name of identifier
	public String getIdName() {
		String res = null;
		if (id != null) {
			res = id.getName();
		} else {
			System.err.println("Error: using undeclared variable.");
			System.exit(1);
		}
		return res;
	}

	// get the value of Identifier
	public int getIdVal() {
		int res = -1;
		if (id != null) {
			res = id.getVal();
		} else {
			System.err.println("Error: using undeclared variable.");
			System.exit(1);
		}
		return res;
	}

	// return the following id list
	public IdList nextList() {
		return idList;
	}

	// parser of IdList
	public void parseIdList() {
		Tokenizer tokenizer = Tokenizer.create();
		id = Id.parseId();

		// consume "id"
		tokenizer.skipToken();

		// check if there exist a comma
		TokenKind kind = tokenizer.getToken();
		if (kind == TokenKind.COMMA) {

			// consume comma
			tokenizer.skipToken();

			// parse IdList
			idList = new IdList();
			idList.parseIdList();
		}
	}

	// printer of IdList
	public void printIdList() {
		id.printId();
		if (idList != null) {
			System.out.print(", ");
			idList.printIdList();
		}
	}

	// executor of IdList
	public void execIdList() {
		// no code needed here
	}
}
