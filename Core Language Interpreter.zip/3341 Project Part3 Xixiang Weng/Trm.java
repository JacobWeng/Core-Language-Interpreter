package edu.c3341;

public class Trm {
    private Op op;
    private Trm trm;
    private boolean isMultiply;
    
    // evaluate the Trm in different cases
    public int evalTrm(){
    	int res = op.evalOp();
        if(isMultiply) {
        	res *= trm.evalTrm();
        }
        return res;
    }
    
    // parser of Trm
    public void parseTrm(){
        Tokenizer tokenizer=Tokenizer.create();
        op = new Op();
        op.parseOp();
        
        // consume ")" after op
        tokenizer.skipToken();
        TokenKind kind=tokenizer.getToken();
        
        // check if there exists multiply
        if(kind==TokenKind.MULTIPLICATION_OPERATOR){
        	
            //consume "*"
            tokenizer.skipToken();
            isMultiply=true;
            trm=new Trm();
            trm.parseTrm();
        }
    }
    
    // printer of Trm
    public void printTrm(){
        op.printOp();
        if(isMultiply){
            System.out.print(" * ");
            trm.printTrm();
        }
    }
    
    // executor of Trm
    public void execTrm() {
    	// no code needed here
    }
}
