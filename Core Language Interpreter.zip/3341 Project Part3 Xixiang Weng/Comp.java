package edu.c3341;

public class Comp {
    private Op op1;
    private Op op2;
    private boolean isNotEqualTest;
    private boolean isEqualTest;
    private boolean isSmallerTest;
    private boolean isLargerTest;
    private boolean isSmallerOrEqualTest;
    private boolean isLargeOrEqualTest;

    // evaluate comp in different cases
    public boolean evalComp(){
    	boolean res = false;
        if(isNotEqualTest){
            res = op1.evalOp() != op2.evalOp();
        }else if(isEqualTest){
            res = op1.evalOp() == op2.evalOp();
        }else if (isSmallerTest){
            res = op1.evalOp() < op2.evalOp();
        }else if(isLargerTest){
            res = op1.evalOp() > op2.evalOp();
        }else if(isSmallerOrEqualTest){
            res = op1.evalOp() <= op2.evalOp();
        }else if(isLargeOrEqualTest){
            res = op1.evalOp() >= op2.evalOp();
        }
        return res;
    }
    
    public void parseComp(){
        Tokenizer tokenizer = Tokenizer.create();
        TokenKind kind = tokenizer.getToken();
        
        // check "("
        if(kind!=TokenKind.LEFT_PARENTHESIS){
            System.err.println("Error: missing left parenthesis)");
            System.exit(1);
        }
        
        //consume "("
        tokenizer.skipToken();
        op1 = new Op();
        op1.parseOp();
        
        //consume "op1"
        tokenizer.skipToken();
        kind=tokenizer.getToken();
        
        // consume "comp op"
        tokenizer.skipToken();
        op2 = new Op();
        op2.parseOp();
        if(kind == TokenKind.NOT_EQUAL_TEST){
            isNotEqualTest = true;
        }else if(kind == TokenKind.EQUALITY_TEST){
            isEqualTest = true;
        }else if(kind == TokenKind.SMALLER_TEST){
            isSmallerTest = true;
        }else if(kind == TokenKind.LARGER_TEST){
            isLargerTest = true;
        }else if(kind == TokenKind.SMALLER_OR_EQUAL_TEST){
            isSmallerOrEqualTest = true;
        }else if(kind == TokenKind.LARGER_OR_EQUAL_TEST){
            isLargeOrEqualTest = true;
        }else{
            System.err.println("Error: wrong syntax in operation");
            System.exit(1);
        }
        
        // consume "op2"
        tokenizer.skipToken();
        kind = tokenizer.getToken();
        if(kind != TokenKind.RIGHT_PARENTHESIS){
            System.err.println("Error: missing right parenthesis");
            System.exit(1);
        }
        
        // consume ")"
        tokenizer.skipToken();
    }

    // printer of Comp
    public void printComp(){
        System.out.print("(");
        op1.printOp();
        if(isNotEqualTest){
            System.out.print(" != ");
        }else if(isEqualTest){
            System.out.print(" == ");
        }else if(isSmallerTest){
            System.out.print(" < ");
        }else if(isLargerTest){
            System.out.print(" > ");
        }else if(isSmallerOrEqualTest){
            System.out.print(" <= ");
        } else if (isLargeOrEqualTest) {
            System.out.print(" >= ");
        }
        op2.printOp();
        System.out.print(")");
    }
    
    //executor of Comp
    public void execComp() {
    	// no code needed here
    }
}
