package edu.c3341;

public class Decl {
	private IdList il;

	// parser of Decl
	public void parseDecl() {
		Tokenizer tokenizer = Tokenizer.create();
		TokenKind kind = tokenizer.getToken();

		// check if Decl start with keyword-int
		if (kind != TokenKind.INT) {
			System.err.println("Error: decl should start with keyword-int");
			System.exit(1);
		}

		// consume "int"
		tokenizer.skipToken();
		il = new IdList();
		il.parseIdList();

		// check id the Decl end with semicolon
		kind = tokenizer.getToken();
		if (kind != TokenKind.SEMICOLON) {
			System.err.println("Error: decl should end with semicolon");
			System.exit(1);
		}

		// consume ";"
		tokenizer.skipToken();
	}

	// printer of Decl
	public void printDecl() {
		PrettyPrint.print("int ");
		il.printIdList();
		System.out.println(";");
	}

	// executor of Decl
	public void execDecl() {
		// no code needed here
	}
}
