package edu.c3341;

public class Id {
    private String name;
    private int val;
    private boolean initialized;
    public static Id[] IdList = new Id[20]; // assuming total number of Id will not be more than 20
    public static int numOfId = 0;
    private Id(String name){
        this.name = name;
    }
    
    // get the Id object
    public static Id getId(String name){
        for(int i = 0; i < numOfId; i++){
            Id id = IdList[i];
            if(id.name.equals(name)){
                return id;
            }
        }
        System.err.println("Error: Attempt to use undeclared variable " + name + ".");
        System.exit(1);
        return null;
    }
    
    // getter of the instance variable name
    public String getName(){
        return this.name;
    }
    
    // setter of the instance variable val
    public void setValue(int v){
        this.val = v;
        this.initialized = true;
    }
    
    // getter of the instance variable val
    public int getVal(){
        if(!initialized){
            System.err.println("Error: Attempt to use variable " + this.name + " without prior initialization.");
            System.exit(1);
        }
        return this.val;
    }
    
    // parser of Id
    public static Id parseId(){
        Tokenizer tokenizer = Tokenizer.create();
        String idName = tokenizer.idName();
        if(idName == null){
            System.err.println("Error: don't exist this id");
            System.exit(1);
        }
        for(int i = 0; i < numOfId; i++){
            if(IdList[i].name.equals(idName)){
                return IdList[i];
            }
        }
        
        // when this id is new, add it into the IdList
        IdList[numOfId] = new Id(idName);
        numOfId++;
        return IdList[numOfId - 1];
    }
    
    // printer of Id
    public void printId(){
        System.out.print(this.name);
    }
    
    // executor of Id
    public void execId() {
    	// no code needed here
    }
}
